package com.nhnacademy.exam.main;

import java.util.List;

public class PayPolicy {
    List<String> timeList;
    List<Long> payList;

    public List<String> getTimeList() {
        return null;
    }

    public List<Long> getPayList() {
        return null;
    }
}
