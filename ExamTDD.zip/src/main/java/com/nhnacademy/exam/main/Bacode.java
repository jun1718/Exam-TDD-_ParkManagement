package com.nhnacademy.exam.main;

public class Bacode {
    String bacode = "";

    public void setBacode(String bacode) {
        this.bacode = bacode;
    }

    public String getBacode() {
        return bacode;
    }
}
