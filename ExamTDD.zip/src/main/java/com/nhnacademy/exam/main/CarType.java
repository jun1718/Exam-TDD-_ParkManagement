package com.nhnacademy.exam.main;

public enum CarType {
    BASIC, LIGHT, TRUCK
}
