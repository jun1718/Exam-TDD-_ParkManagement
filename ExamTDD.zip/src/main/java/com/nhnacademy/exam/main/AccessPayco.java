package com.nhnacademy.exam.main;

public class AccessPayco {
    public boolean access(Bacode bacode) {
        return false;
    }
}
