package com.nhnacademy.exam.main;

import java.util.Map;

public class Structor {

    public Map<String, Integer> getStructor() {
        return null;
    }
}
